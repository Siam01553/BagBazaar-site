// Basic App component
import React from 'react';
export default function App() {
  return <h1>BagBazaar Coming Soon!</h1>;
}